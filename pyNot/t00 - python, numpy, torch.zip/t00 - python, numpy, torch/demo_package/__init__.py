"""
Demo package init file.
This file used to be required for defining a python pacakge, until python 3.3.
"""

# Package init code can be written here
